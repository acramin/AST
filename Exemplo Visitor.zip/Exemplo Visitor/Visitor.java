import java.util.ArrayList;

public class Visitor {
    public static void main(String[] args) {
        // list of shapes
        ArrayList<Shape> shapes = new ArrayList<>();
        // ass some shapes
        shapes.add(new Circle(3.0));
        shapes.add(new Rectangle(5.0, 4.0));
        // create a visitor
        AreaCalculator calculator = new AreaCalculator();
        // visit all the shapes
        for (Shape s : shapes) {
            s.accept(calculator);
        }
    }
}

// Interface Visitor
interface ShapeVisitor {
    void visit(Circle circle);

    void visit(Rectangle rectangle);
}

// Interface Element
interface Shape {
    void accept(ShapeVisitor visitor);
}

// Implementação de um elemento concreto (Círculo)
class Circle implements Shape {

    public Circle(Double radius) {
        this.radius = radius;
    }

    private Double radius;

    public Double getRadius() {
        return this.radius;
    }

    public void setRadius(Double radius) {
        this.radius = radius;
    }

    public void accept(ShapeVisitor visitor) {
        visitor.visit(this);
    }
}

// Implementação de outro elemento concreto (Retângulo)
class Rectangle implements Shape {

    public Rectangle(Double width, Double length) {
        this.width = width;
        this.length = length;
    }

    private Double width;
    private Double length;

    public Double getWidth() {
        return this.width;
    }

    public void setWidth(Double width) {
        this.width = width;
    }

    public Double getLength() {
        return this.length;
    }

    public void setLength(Double length) {
        this.length = length;
    }

    public void accept(ShapeVisitor visitor) {
        visitor.visit(this);
    }
}

// Implementação do visitante concreto para cálculo de área
class AreaCalculator implements ShapeVisitor {
    public void visit(Circle circle) {
        // lógica de cálculo de área do círculo
        System.out.println(Math.PI * Math.pow(circle.getRadius(), 2));
    }

    public void visit(Rectangle rectangle) {
        // lógica de cálculo de área do retângulo
        System.out.println(rectangle.getLength() * rectangle.getWidth());
    }
}
