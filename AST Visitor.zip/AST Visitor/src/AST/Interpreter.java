package AST;

import AST.Expr.DivExpr;
import AST.Expr.IdExpr;
import AST.Expr.IntConstExpr;
import AST.Expr.MulExpr;
import AST.Expr.SubExpr;
import AST.Expr.SumExpr;

public class Interpreter implements Visitor {

    @Override
    public int visit(SumExpr e) {
        return e.e1.accept(this) + e.e2.accept(this);
    }

    @Override
    public int visit(SubExpr e) {
        return e.e1.accept(this) - e.e2.accept(this);
    }

    @Override
    public int visit(MulExpr e) {
        return e.e1.accept(this) * e.e2.accept(this);
    }

    @Override
    public int visit(DivExpr e) {
        return e.e1.accept(this) / e.e2.accept(this);
    }

    @Override
    public int visit(IdExpr e) {
        return 0;
    }

    @Override
    public int visit(IntConstExpr e) {
        return e.value;
    }
}
