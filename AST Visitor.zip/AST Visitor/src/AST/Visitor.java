package AST;

import AST.Expr.SumExpr;
import AST.Expr.MulExpr;
import AST.Expr.SubExpr;
import AST.Expr.DivExpr;
import AST.Expr.IdExpr;
import AST.Expr.IntConstExpr;

public interface Visitor {
    public int visit(SumExpr e);

    public int visit(SubExpr e);

    public int visit(MulExpr e);

    public int visit(DivExpr e);

    public int visit(IdExpr e);

    public int visit(IntConstExpr e);
}
