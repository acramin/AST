package AST.Expr;

import AST.Visitor;

public class IdExpr implements Expr {
    public String name;

    public IdExpr(String name) {
        this.name = name;
    }

    @Override
    public int accept(Visitor v) {
        return v.visit(this);
    }
}
