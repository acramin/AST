package AST.Expr;

import AST.Visitor;

public interface Expr {
    public int accept(Visitor v);
}
