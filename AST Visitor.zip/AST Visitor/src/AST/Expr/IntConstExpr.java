package AST.Expr;

import AST.Visitor;

public class IntConstExpr implements Expr {
    public Integer value;

    public IntConstExpr(Integer value) {
        this.value = value;
    }

    @Override
    public int accept(Visitor v) {
        return v.visit(this);
    }

}
