import AST.Expr.*;
import AST.Interpreter;

public class App {
    public static void main(String[] args) throws Exception {
        // 10 * (5-8) + 4 
        SumExpr e = new SumExpr(
                new MulExpr(
                        new IntConstExpr(10),
                        new SubExpr(
                                new IntConstExpr(5),
                                new IntConstExpr(8))),
                new IntConstExpr(4));

        System.out.println(new Interpreter().visit(e));
    }
}
